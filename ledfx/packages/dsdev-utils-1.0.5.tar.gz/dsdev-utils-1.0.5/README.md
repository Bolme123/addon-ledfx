[![PyPI version](https://badge.fury.io/py/dsdev-utils.svg)](http://badge.fury.io/py/dsdev-utils) [![Build Status](https://travis-ci.org/JMSwag/dsdev-utils.svg?branch=master)](https://travis-ci.org/JMSwag/dsdev-utils) [![Build status](https://ci.appveyor.com/api/projects/status/sepw766w1qrw8wa6?svg=true)](https://ci.appveyor.com/project/JMSwag/dsdev-utils)

# DSDev Utils
##### Various utility function I seem to always use

###### [Change Log](https://github.com/JMSwag/dsdev-utils/docs/changelog.md "Change Log")

## To Install

#### From pip:

    $ pip install dsdev-utils

#### From source:

    $ python setup.py install
