.. currentmodule:: aubio
.. default-domain:: py

Synthesis
---------

.. autoclass:: sampler

.. autoclass:: wavetable
